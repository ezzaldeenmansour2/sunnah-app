import 'dart:io';

import 'package:material_ui/material_ui.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package_store.dart';
import 'screens/library_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Desktop only: sqflite's global databaseFactory is not initialized on
  // Linux/Windows/macOS — back it with FFI. On Android/iOS sqflite uses
  // the platform implementation and this branch never runs.
  if (Platform.isLinux || Platform.isWindows || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }
  final docs = await getApplicationDocumentsDirectory();
  final store = PackageStore(documentsDir: Directory(docs.path));
  runApp(SunnahApp(store: store));
}

class SunnahApp extends StatelessWidget {
  const SunnahApp({super.key, required this.store});

  final PackageStore store;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سُنّة | SUNNAH',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        colorScheme: .fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
      home: LibraryScreen(store: store),
    );
  }
}
