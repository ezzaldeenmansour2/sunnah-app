import 'package:material_ui/material_ui.dart';

import '../package_store.dart';

/// Hadith detail screen: title, narrator, full text, takhrij/source line
/// and a full reference line (book + edition + hadith number + source).
/// All data comes from the imported package's own content database.
class HadithDetailScreen extends StatefulWidget {
  const HadithDetailScreen({
    super.key,
    required this.store,
    required this.package,
    required this.chunkId,
  });

  final PackageStore store;
  final ImportedPackageInfo package;
  final int chunkId;

  @override
  State<HadithDetailScreen> createState() => _HadithDetailScreenState();
}

class _HadithDetailScreenState extends State<HadithDetailScreen> {
  SearchResult? _chunk;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final chunk = await widget.store
        .getChunk(widget.package.packageId, widget.chunkId);
    if (!mounted) return;
    setState(() {
      _chunk = chunk;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pkg = widget.package;
    final chunk = _chunk;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          chunk == null
              ? pkg.title
              : (chunk.kind == 'hadith'
                  ? 'الحديث ${chunk.refNumber ?? ''}'
                  : (chunk.title ?? pkg.title)),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : chunk == null
              ? const Center(child: Text('تعذر تحميل الحديث.'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (chunk.title != null && chunk.title!.isNotEmpty)
                        Text(
                          chunk.title!,
                          style: Theme.of(context).textTheme.titleLarge,
                          textAlign: TextAlign.center,
                        ),
                      if (chunk.narrator != null && chunk.narrator!.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(
                            'الراوي: ${chunk.narrator}',
                            style: Theme.of(context).textTheme.bodyLarge,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      const SizedBox(height: 16),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text(
                            chunk.text,
                            style: Theme.of(context)
                                .textTheme
                                .bodyLarge
                                ?.copyWith(height: 1.9),
                            textAlign: TextAlign.justify,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Divider(),
                      _ReferenceRow(
                        label: 'التخريج / المصدر',
                        value: pkg.source ?? 'غير مذكور',
                      ),
                      const SizedBox(height: 8),
                      _ReferenceRow(
                        label: 'المرجع',
                        value:
                            '${pkg.title} — ${pkg.edition}\nرقم الحديث: ${chunk.refNumber ?? '—'}\nالمصدر: ${pkg.source ?? 'غير مذكور'}',
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _ReferenceRow extends StatelessWidget {
  const _ReferenceRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context)
              .textTheme
              .titleSmall
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(value, style: Theme.of(context).textTheme.bodyMedium),
      ],
    );
  }
}
