import 'package:file_picker/file_picker.dart';
import 'package:material_ui/material_ui.dart';

import '../package_store.dart';
import 'search_screen.dart';

/// Home / library screen: lists imported content packages and imports new
/// ones from `.sunnahpkg` files.
class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key, required this.store});

  final PackageStore store;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  List<ImportedPackageInfo> _packages = [];
  bool _loading = true;
  bool _importing = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final list = await widget.store.listImportedPackages();
    if (!mounted) return;
    setState(() {
      _packages = list;
      _loading = false;
    });
  }

  Future<void> _importPackage() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['sunnahpkg'],
    );
    if (result == null || result.files.single.path == null) return;
    setState(() => _importing = true);
    final outcome =
        await widget.store.importPackage(result.files.single.path!);
    if (!mounted) return;
    setState(() => _importing = false);
    await _showImportResult(outcome);
    await _refresh();
  }

  Future<void> _showImportResult(ImportOutcome outcome) {
    return showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(outcome.ok ? 'تم الاستيراد بنجاح' : 'فشل الاستيراد'),
        content: outcome.ok
            ? Text('تم استيراد الحزمة ${outcome.packageId} بنجاح.')
            : SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('رفضت الحزمة للأسباب التالية:'),
                    const SizedBox(height: 8),
                    for (final e in outcome.errors)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Text('• $e'),
                      ),
                  ],
                ),
              ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('سُنّة | SUNNAH'),
        actions: [
          TextButton.icon(
            onPressed: _importing ? null : _importPackage,
            icon: const Icon(Icons.file_download),
            label: const Text('استيراد حزمة'),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _importing
              ? const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 12),
                      Text('جارٍ التحقق من الحزمة واستيرادها...'),
                    ],
                  ),
                )
              : _packages.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'لا توجد كتب مستوردة بعد.\n'
                          'استخدم زر «استيراد حزمة» لإضافة كتاب من ملف .sunnahpkg.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _packages.length,
                      itemBuilder: (context, i) {
                        final pkg = _packages[i];
                        return Card(
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          child: ListTile(
                            leading: const Icon(Icons.menu_book),
                            title: Text(pkg.title),
                            subtitle: Text(
                              '${pkg.edition}\n'
                              '${pkg.hadithCount} حديثاً · الإصدار ${pkg.version}',
                            ),
                            isThreeLine: true,
                            trailing: const Icon(Icons.chevron_left),
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (_) => SearchScreen(
                                  store: widget.store,
                                  package: pkg,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
