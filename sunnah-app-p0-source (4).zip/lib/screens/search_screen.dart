import 'package:material_ui/material_ui.dart';

import '../package_store.dart';
import 'hadith_detail_screen.dart';

/// Search screen for one imported package: FTS5 phrase search first,
/// keyword fallback (handled inside [PackageStore]).
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.store, required this.package});

  final PackageStore store;
  final ImportedPackageInfo package;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();
  List<SearchResult> _results = [];
  bool _searched = false;
  bool _searching = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final query = _controller.text.trim();
    if (query.isEmpty) return;
    setState(() {
      _searching = true;
      _searched = true;
    });
    final results =
        await widget.store.searchInPackage(widget.package.packageId, query);
    if (!mounted) return;
    setState(() {
      _results = results;
      _searching = false;
    });
  }

  String _snippet(String text) {
    const max = 140;
    return text.length <= max ? text : '${text.substring(0, max)}…';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.package.title)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'ابحث في الكتاب...',
                      border: OutlineInputBorder(),
                    ),
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _search(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _searching ? null : _search,
                  icon: const Icon(Icons.search),
                  tooltip: 'بحث',
                ),
              ],
            ),
          ),
          if (_searching) const LinearProgressIndicator(),
          Expanded(
            child: !_searched
                ? Center(
                    child: Text(
                      '${widget.package.hadithCount} حديثاً في هذا الكتاب.\n'
                      'ابحث بكلمة أو عبارة أو رقم حديث.',
                      textAlign: TextAlign.center,
                    ),
                  )
                : _results.isEmpty
                    ? const Center(child: Text('لا توجد نتائج مطابقة.'))
                    : ListView.builder(
                        itemCount: _results.length,
                        itemBuilder: (context, i) {
                          final r = _results[i];
                          final label = r.kind == 'hadith'
                              ? 'الحديث ${r.refNumber ?? ''}'
                              : (r.title ?? r.kind);
                          return Card(
                            margin: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            child: ListTile(
                              title: Text(label),
                              subtitle: Text(_snippet(r.text)),
                              trailing: const Icon(Icons.chevron_left),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                  builder: (_) => HadithDetailScreen(
                                    store: widget.store,
                                    package: widget.package,
                                    chunkId: r.id,
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
