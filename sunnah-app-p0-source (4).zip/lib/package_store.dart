/// Package import, registry and search (P0).
///
/// Pure logic, testable without widgets: the Android app picks a
/// `.sunnahpkg` file, this class verifies it (signature, hashes, licence,
/// schema, version — via sunnah_core), extracts `content.sqlite` into the
/// app documents directory and records it in a small registry database.
///
/// Imports are atomic: on ANY verification failure nothing is extracted
/// and nothing is recorded.
library;

import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter/services.dart' show AssetBundle, rootBundle;
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:sunnah_core/sunnah_core.dart';

/// One row of the imported-packages registry, enriched with book metadata
/// read from the package's own content database.
class ImportedPackageInfo {
  ImportedPackageInfo({
    required this.packageId,
    required this.version,
    required this.keyId,
    required this.dbPath,
    required this.importedAt,
    required this.title,
    required this.author,
    required this.edition,
    required this.publisher,
    required this.source,
    required this.hadithCount,
    required this.chunkCount,
  });

  final String packageId;
  final int version;
  final String keyId;
  final String dbPath;
  final DateTime importedAt;
  final String title;
  final String? author;
  final String edition;
  final String? publisher;
  final String? source;
  final int hadithCount;
  final int chunkCount;
}

/// One chunk row returned by a search (or a direct lookup).
class SearchResult {
  SearchResult({
    required this.id,
    required this.kind,
    required this.refNumber,
    required this.title,
    required this.narrator,
    required this.text,
  });

  factory SearchResult.fromRow(Map<String, Object?> row) {
    return SearchResult(
      id: row['id'] as int,
      kind: row['kind'] as String,
      refNumber: row['ref_number'] as String?,
      title: row['title'] as String?,
      narrator: row['narrator'] as String?,
      text: row['text'] as String,
    );
  }

  final int id;
  final String kind;
  final String? refNumber;
  final String? title;
  final String? narrator;
  final String text;
}

/// Outcome of [PackageStore.importPackage].
class ImportOutcome {
  ImportOutcome({required this.ok, required this.errors, this.packageId});

  final bool ok;
  final List<String> errors;
  final String? packageId;
}

class PackageStore {
  /// [documentsDir] is the app documents directory (real on the device,
  /// a temp dir in tests). [trustedKeysOverride] bypasses the asset file
  /// (tests). [assetBundle] defaults to [rootBundle].
  PackageStore({
    required this.documentsDir,
    this.trustedKeysOverride,
    AssetBundle? assetBundle,
  }) : assetBundle = assetBundle ?? rootBundle;

  final Directory documentsDir;
  final List<TrustedKey>? trustedKeysOverride;
  final AssetBundle assetBundle;

  Database? _registryDb;

  /// Load the trusted publisher keys from `assets/trusted_keys.json`
  /// (or from [trustedKeysOverride] when set).
  Future<List<TrustedKey>> loadTrustedKeys() async {
    if (trustedKeysOverride != null) return trustedKeysOverride!;
    final raw = await assetBundle.loadString('assets/trusted_keys.json');
    final list = jsonDecode(raw) as List<dynamic>;
    return list
        .map(
          (e) => TrustedKey(
            keyId: (e as Map<String, dynamic>)['key_id'] as String,
            publicKeyBase64: e['public_key_base64'] as String,
          ),
        )
        .toList();
  }

  Future<Database> _registry() async {
    final db = _registryDb;
    if (db != null && db.isOpen) return db;
    final path = p.join(documentsDir.path, 'sunnah_registry.db');
    _registryDb = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE imported_packages (
            package_id TEXT PRIMARY KEY,
            version INTEGER NOT NULL,
            key_id TEXT NOT NULL,
            db_path TEXT NOT NULL,
            imported_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _registryDb!;
  }

  Future<void> close() async {
    await _registryDb?.close();
    _registryDb = null;
  }

  /// Peek at the manifest inside a ZIP to find its package_id.
  /// Used ONLY to look up the installed version for verification check 6;
  /// trust comes from [verifyPackage], never from this peek.
  Future<String?> _peekPackageId(String zipPath) async {
    try {
      final bytes = await File(zipPath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final files = archive.files.where((f) => f.name == 'manifest.json');
      if (files.isEmpty) return null;
      final manifest =
          jsonDecode(utf8.decode(files.first.content as List<int>))
              as Map<String, dynamic>;
      return manifest['package_id'] as String?;
    } catch (_) {
      return null;
    }
  }

  /// Import a `.sunnahpkg` file. Verifies first; extracts and records
  /// ONLY on success. Returns the verification errors on failure.
  Future<ImportOutcome> importPackage(String filePath) async {
    final tmp = await Directory.systemTemp.createTemp('sunnah_import_');
    final tmpPkg = p.join(tmp.path, 'package.sunnahpkg');
    try {
      await File(filePath).copy(tmpPkg);
      final trusted = await loadTrustedKeys();

      // Installed version (if any) for verification check 6.
      int? installedVersion;
      final peekedId = await _peekPackageId(tmpPkg);
      if (peekedId != null) {
        final db = await _registry();
        final rows = await db.query(
          'imported_packages',
          columns: ['version'],
          where: 'package_id = ?',
          whereArgs: [peekedId],
        );
        if (rows.isNotEmpty) installedVersion = rows.first['version'] as int;
      }

      final verification = await verifyPackage(
        packagePath: tmpPkg,
        trustedKeys: trusted,
        appSchemaVersion: kSchemaVersion,
        installedVersion: installedVersion,
      );
      if (!verification.ok) {
        return ImportOutcome(ok: false, errors: verification.errors);
      }
      final manifest = verification.manifest!;
      final packageId = manifest['package_id'] as String;
      final packageVersion = manifest['package_version'] as int;
      final keyId = manifest['key_id'] as String;

      // Extract content.sqlite (hashes already verified by verifyPackage).
      final bytes = await File(tmpPkg).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final dbFiles =
          archive.files.where((f) => f.name == 'content.sqlite');
      if (dbFiles.isEmpty) {
        return ImportOutcome(
          ok: false,
          errors: ['content.sqlite غير موجود في الحزمة'],
        );
      }
      final pkgDir = Directory(p.join(documentsDir.path, 'packages', packageId));
      await pkgDir.create(recursive: true);
      final dbPath = p.join(pkgDir.path, 'content.sqlite');
      try {
        await File(dbPath).writeAsBytes(dbFiles.first.content as List<int>);
        final db = await _registry();
        await db.insert(
          'imported_packages',
          {
            'package_id': packageId,
            'version': packageVersion,
            'key_id': keyId,
            'db_path': dbPath,
            'imported_at': DateTime.now().toUtc().toIso8601String(),
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      } catch (e) {
        // Roll back the extraction: nothing half-imported.
        if (await pkgDir.exists()) await pkgDir.delete(recursive: true);
        return ImportOutcome(ok: false, errors: ['فشل حفظ الحزمة: $e']);
      }
      return ImportOutcome(ok: true, errors: const [], packageId: packageId);
    } finally {
      if (await tmp.exists()) await tmp.delete(recursive: true);
    }
  }

  /// List imported packages with book metadata from each content DB.
  Future<List<ImportedPackageInfo>> listImportedPackages() async {
    final db = await _registry();
    final rows = await db.query(
      'imported_packages',
      orderBy: 'imported_at DESC',
    );
    final out = <ImportedPackageInfo>[];
    for (final row in rows) {
      final packageId = row['package_id'] as String;
      final dbPath = row['db_path'] as String;
      var title = packageId;
      String? author;
      var edition = '';
      String? publisher;
      String? source;
      var hadithCount = 0;
      var chunkCount = 0;
      try {
        final contentDb = await openDatabase(dbPath, readOnly: true);
        try {
          final bookRows = await contentDb.rawQuery('''
            SELECT b.title, b.author, e.edition_label, e.publisher, e.source
            FROM books b JOIN editions e ON e.book_id = b.id
            LIMIT 1
          ''');
          if (bookRows.isNotEmpty) {
            final r = bookRows.first;
            title = r['title'] as String;
            author = r['author'] as String?;
            edition = r['edition_label'] as String;
            publisher = r['publisher'] as String?;
            source = r['source'] as String?;
          }
          final counts = await contentDb.rawQuery('''
            SELECT
              (SELECT COUNT(*) FROM chunks WHERE kind = 'hadith') AS hadiths,
              (SELECT COUNT(*) FROM chunks) AS chunks
          ''');
          hadithCount = counts.first['hadiths'] as int;
          chunkCount = counts.first['chunks'] as int;
        } finally {
          await contentDb.close();
        }
      } catch (_) {
        // Content DB unreadable: still list the package with fallback data.
      }
      out.add(
        ImportedPackageInfo(
          packageId: packageId,
          version: row['version'] as int,
          keyId: row['key_id'] as String,
          dbPath: dbPath,
          importedAt: DateTime.parse(row['imported_at'] as String),
          title: title,
          author: author,
          edition: edition,
          publisher: publisher,
          source: source,
          hadithCount: hadithCount,
          chunkCount: chunkCount,
        ),
      );
    }
    return out;
  }

  /// Open an imported package's content database (read-only).
  Future<Database> openPackageDb(String packageId) async {
    final db = await _registry();
    final rows = await db.query(
      'imported_packages',
      columns: ['db_path'],
      where: 'package_id = ?',
      whereArgs: [packageId],
      limit: 1,
    );
    if (rows.isEmpty) {
      throw StateError('الحزمة غير مستوردة: $packageId');
    }
    return openDatabase(rows.first['db_path'] as String, readOnly: true);
  }

  /// Search one package: exact-phrase FTS5 search first, keyword (AND)
  /// fallback when the phrase search finds nothing.
  Future<List<SearchResult>> searchInPackage(
    String packageId,
    String query, {
    int limit = 10,
  }) async {
    final normalized = normalizeArabic(query);
    if (normalized.isEmpty) return const [];
    final db = await openPackageDb(packageId);
    try {
      var rows = await db.rawQuery(kFtsPhraseSearchSql, ['"$normalized"', limit]);
      if (rows.isEmpty) {
        final terms =
            normalized.split(' ').where((t) => t.isNotEmpty).toList();
        if (terms.length > 1) {
          final match = terms.map((t) => '"$t"').join(' AND ');
          rows = await db.rawQuery(kFtsPhraseSearchSql, [match, limit]);
        }
      }
      return rows.map(SearchResult.fromRow).toList();
    } finally {
      await db.close();
    }
  }

  /// One chunk by id (for the detail screen).
  Future<SearchResult?> getChunk(String packageId, int chunkId) async {
    final db = await openPackageDb(packageId);
    try {
      final rows = await db.query(
        'chunks',
        where: 'id = ?',
        whereArgs: [chunkId],
        limit: 1,
      );
      if (rows.isEmpty) return null;
      return SearchResult.fromRow(rows.first);
    } finally {
      await db.close();
    }
  }
}
