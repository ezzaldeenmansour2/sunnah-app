package com.sunnah.app.sunnah

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
