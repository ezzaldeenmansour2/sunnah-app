/// P0 tests — use the REAL signed package produced by SUNNAH Studio.
/// No fake content anywhere: the real Forty Nawawi package, a tampered
/// copy of it, and a package signed by a different (untrusted) key.
library;

import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:sunnah/package_store.dart';
import 'package:sunnah/screens/library_screen.dart';
import 'package:sunnah_core/sunnah_core.dart';

const String kRealKeyId = 'sunnah-main-2026';
const String kRealPublicKeyBase64 =
    'bX85cPbers/qklneCsB9VDph3xxn9HkV5zEj2hkQeQU=';

/// Absolute path of the real signed package, resolved from this test file.
String get realPackagePath {
  final testDir = p.dirname(Platform.script.toFilePath());
  final candidate = p.normalize(
    p.join(testDir, '..', 'test-output', 'arbaeen-nawawi-v1.sunnahpkg'),
  );
  if (File(candidate).existsSync()) return candidate;
  return '/home/hatch/workspace/sunnah-app/test-output/'
      'arbaeen-nawawi-v1.sunnahpkg';
}

Future<Directory> _freshDocsDir() =>
    Directory.systemTemp.createTemp('sunnah_test_docs_');

PackageStore _store(Directory docs) => PackageStore(
      documentsDir: docs,
      trustedKeysOverride: [
        TrustedKey(
          keyId: kRealKeyId,
          publicKeyBase64: kRealPublicKeyBase64,
        ),
      ],
    );

void main() {
  setUpAll(() {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  });

  late Directory docs;
  late PackageStore store;

  setUp(() async {
    docs = await _freshDocsDir();
    store = _store(docs);
  });

  tearDown(() async {
    await store.close();
    if (await docs.exists()) await docs.delete(recursive: true);
  });

  test('trusted keys load from the bundled asset file', () async {
    final assetStore = PackageStore(documentsDir: docs);
    final keys = await assetStore.loadTrustedKeys();
    expect(keys, hasLength(1));
    expect(keys.first.keyId, kRealKeyId);
    expect(keys.first.publicKeyBase64, kRealPublicKeyBase64);
  });

  test('imports the real signed package and searches it offline', () async {
    final outcome = await store.importPackage(realPackagePath);
    expect(outcome.ok, isTrue, reason: outcome.errors.join('; '));
    expect(outcome.packageId, 'arbaeen-nawawi');

    final list = await store.listImportedPackages();
    expect(list, hasLength(1));
    expect(list.first.title, 'الأربعون النووية');
    expect(list.first.edition, contains('أم القرى'));
    expect(list.first.hadithCount, 42);

    // Exact-phrase search: hadith 1 first, with its real text.
    final phrase =
        await store.searchInPackage('arbaeen-nawawi', 'الأعمال بالنيات');
    expect(phrase, isNotEmpty);
    expect(phrase.first.refNumber, '1');
    expect(phrase.first.text, contains('إنما الأعمال بالنيات'));

    // Keyword fallback (no exact phrase exists for these two words).
    // NOTE: the query uses 'عمر الخطاب' (not 'الأعمال النيات'): FTS5
    // tokenizes Arabic as written, so 'النيات' never occurs as a bare
    // token — the text has 'بالنيات' (بـ attached). 'عمر' and 'الخطاب'
    // do occur as bare tokens, so the AND fallback is genuinely exercised.
    final keywords =
        await store.searchInPackage('arbaeen-nawawi', 'عمر الخطاب');
    expect(keywords, isNotEmpty);
    expect(keywords.any((r) => r.refNumber == '1'), isTrue);
  });

  test('rejects a tampered package and imports nothing', () async {
    final tamperedDir = await Directory.systemTemp.createTemp('sunnah_tamper_');
    final tamperedPath = p.join(tamperedDir.path, 'tampered.sunnahpkg');
    try {
      final bytes = await File(realPackagePath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final rebuilt = Archive();
      for (final file in archive.files) {
        var content = file.content as List<int>;
        if (file.name == 'content.sqlite') {
          // Flip one byte: the manifest hash no longer matches.
          final mutated = List<int>.from(content);
          mutated[100] = mutated[100] ^ 0xFF;
          content = mutated;
        }
        rebuilt.addFile(ArchiveFile(file.name, content.length, content));
      }
      await File(tamperedPath)
          .writeAsBytes(ZipEncoder().encode(rebuilt));

      final outcome = await store.importPackage(tamperedPath);
      expect(outcome.ok, isFalse);
      expect(outcome.errors, isNotEmpty);
      expect(
        outcome.errors.any((e) => e.contains('بصمة')),
        isTrue,
        reason: outcome.errors.join('; '),
      );

      expect(await store.listImportedPackages(), isEmpty);
      expect(
        Directory(p.join(docs.path, 'packages')).existsSync(),
        isFalse,
      );
    } finally {
      await tamperedDir.delete(recursive: true);
    }
  });

  test('rejects a package signed by an untrusted key', () async {
    final workDir = await Directory.systemTemp.createTemp('sunnah_wrongkey_');
    try {
      // Extract the real content.sqlite and re-sign it with another key.
      final bytes = await File(realPackagePath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final contentFile =
          archive.files.firstWhere((f) => f.name == 'content.sqlite');
      final contentPath = p.join(workDir.path, 'content.sqlite');
      await File(contentPath)
          .writeAsBytes(contentFile.content as List<int>);

      final otherKey = await generatePublisherKey('other-key-2026');
      final wrongKeyPath = p.join(workDir.path, 'wrongkey.sunnahpkg');
      await buildPackage(
        manifest: PackageManifest(
          packageId: 'arbaeen-nawawi-wrongkey',
          packageVersion: 1,
          schemaVersion: kSchemaVersion,
          keyId: otherKey.keyId,
          book: {
            'title': 'الأربعون النووية',
            'author': 'يحيى بن شرف النووي',
            'edition': 'صفحة تقويم أم القرى، كما نُشرت 2026',
            'publisher': null,
            'print_year': null,
            'source': 'ummalquracalendar.org — الأربعون النووية كاملة مكتوبة',
            'license_status': 'public_domain',
            'commercial_allowed': true,
          },
          contents: {'hadiths': 42, 'chunks': 43, 'links': 0},
          files: const [],
        ),
        contentDbPath: contentPath,
        signingKey: otherKey,
        outputPath: wrongKeyPath,
      );

      final outcome = await store.importPackage(wrongKeyPath);
      expect(outcome.ok, isFalse);
      expect(
        outcome.errors.any((e) => e.contains('غير موثوق')),
        isTrue,
        reason: outcome.errors.join('; '),
      );
      expect(await store.listImportedPackages(), isEmpty);
    } finally {
      await workDir.delete(recursive: true);
    }
  });

  testWidgets('library screen lists the imported package', (tester) async {
    // Real async work (file I/O, sqflite FFI, Ed25519 verification) must
    // run outside the fake-async zone of testWidgets, otherwise it never
    // completes. tester.runAsync is the documented way to do that.
    final outcome = await tester.runAsync(
      () => store.importPackage(realPackagePath),
    );
    expect(outcome?.ok, isTrue, reason: outcome?.errors.join('; '));
    await tester.pumpWidget(
      MaterialApp(
        builder: (context, child) => Directionality(
          textDirection: TextDirection.rtl,
          child: child!,
        ),
        home: LibraryScreen(store: store),
      ),
    );
    // NOTE: do NOT use pumpAndSettle here — the loading spinner animates
    // forever, so pumpAndSettle would never return. Alternate real-time
    // waits (so sqflite FFI work completes) with pumps (so fake-zone
    // continuations run and the screen rebuilds) until the list appears.
    for (var i = 0; i < 10; i++) {
      await tester.runAsync(
        () => Future.delayed(const Duration(milliseconds: 100)),
      );
      await tester.pump(const Duration(milliseconds: 100));
      if (find.text('الأربعون النووية').evaluate().isNotEmpty) break;
    }

    expect(find.text('الأربعون النووية'), findsOneWidget);
    expect(find.textContaining('42 حديثاً'), findsOneWidget);
  });
}
