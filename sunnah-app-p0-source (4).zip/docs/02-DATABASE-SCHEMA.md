# مخطط قاعدة البيانات — تطبيق سُنّة | SUNNAH

**المبدأ الحاكم:** قاعدة البيانات **مستقلة عن مصدر البيانات**. لا يوجد عمود واحد في الجداول الأساسية يخص مصدراً بعينه. المصادر طبقة وصفية منفصلة (`data_sources` + `source_records`)، فيُستبدل المصدر أو يُضاف مصدر جديد دون تغيير مخطط التطبيق.
**التقنية:** SQLite عبر `sqflite` في Flutter (نفس تقنية مشاريع مساحة العمل)، مع FTS5 للبحث النصي. الإصدار الأول من المخطط: `schema_version = 1`.

## 1. خريطة الجداول

```
المجال الأساسي (مستقل عن المصدر)
  collections ──< books ──< chapters ──< hadiths ──< commentary_links >── commentary_passages ──< commentary_books
  hadiths ──< bookmarks        narrators ──< hadiths (اختياري)
طبقة المصادر والتحقق
  data_sources ──< source_records (لكل كيان) ──< verification_checks
  import_runs ──< diff_audit        coverage        excluded_records
الحوكمة والإدارة
  admin_users        content_reviews        audit_log        backups
الذكاء الاسترجاعي (اختياري لاحقاً)
  embeddings
```

## 2. الجداول الأساسية

### `collections` — الكتب الحديثية (البخاري، مسلم، السنن...)

```sql
CREATE TABLE collections(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,          -- bukhari | muslim | abudawud ...
  name_ar TEXT NOT NULL,              -- صحيح البخاري
  name_en TEXT,
  compiler_ar TEXT,                   -- محمد بن إسماعيل البخاري
  compiler_en TEXT,
  compiler_death_hijri INTEGER,       -- 256
  total_hadiths INTEGER,              -- من المصدر، قابل للتحديث
  status TEXT NOT NULL DEFAULT 'active', -- active | coming_soon | hidden
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
```

### `books` — الكتب داخل المجموعة (كتاب بدء الوحي...)

```sql
CREATE TABLE books(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id INTEGER NOT NULL REFERENCES collections(id),
  number INTEGER NOT NULL,            -- 1..97 في البخاري
  title_ar TEXT NOT NULL,
  title_en TEXT,
  hadith_first TEXT, hadith_last TEXT, -- نطاق الأرقام (نص لاحتواء العشري)
  UNIQUE(collection_id, number)
);
CREATE INDEX idx_books_collection ON books(collection_id);
```

### `chapters` — الأبواب داخل الكتاب (اختياري في v1)

```sql
CREATE TABLE chapters(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL REFERENCES books(id),
  number INTEGER,
  title_ar TEXT NOT NULL,
  title_en TEXT
);
```

### `hadiths` — نص الحديث (القلب)

```sql
CREATE TABLE hadiths(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id INTEGER NOT NULL REFERENCES collections(id),
  book_id INTEGER REFERENCES books(id),
  chapter_id INTEGER REFERENCES chapters(id),
  hadith_number TEXT NOT NULL,        -- TEXT لا INTEGER: أرقام عشرية فرعية مثل 402.2
  arabic_number TEXT,
  text_ar TEXT NOT NULL,              -- النص الأصلي؛ لا يُعدَّل من الواجهة أبداً
  text_hash TEXT NOT NULL,            -- SHA-256 للنص؛ أساس كشف التغيير عند التحديث
  narrator_id INTEGER REFERENCES narrators(id),
  narrator_verified INTEGER NOT NULL DEFAULT 0, -- 0=غير موثق، 1=موثق بمراجعة
  grade TEXT,                         -- صحيح | حسن | ضعيف | NULL عند عدم توفر حكم
  grade_source TEXT,                  -- من الذي حكم؟ (الألباني، ابن حجر...)
  grade_basis TEXT,                   -- أساس الحكم (الإدراج في المجموعة...)
  status TEXT NOT NULL DEFAULT 'published', -- draft | pending_review | published | under_review | withdrawn
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE(collection_id, hadith_number)
);
CREATE INDEX idx_hadiths_collection_number ON hadiths(collection_id, hadith_number);
CREATE INDEX idx_hadiths_book ON hadiths(book_id);
```

**قاعدة صارمة:** دالة التحديث في التطبيق ترفض أي تغيير على `text_ar` ما لم يأتِ من مستورد موثّق ويدخل طابور المراجعة. التعديل اليدوي يطال البيانات الوصفية فقط.

### `narrators` — الرواة (الصحابة أساساً)

```sql
CREATE TABLE narrators(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_ar TEXT NOT NULL UNIQUE,
  name_en TEXT,
  bio_ar TEXT,                        -- ترجمة مختصرة موثقة المصدر
  bio_source TEXT
);
```

### `commentary_books` — كتب الشروح

```sql
CREATE TABLE commentary_books(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title_ar TEXT NOT NULL,             -- فتح الباري بشرح صحيح البخاري
  author_ar TEXT NOT NULL,            -- ابن حجر العسقلاني
  author_death_hijri INTEGER,         -- 852
  edition TEXT,                       -- ط السلفية / ط دار المعرفة...
  publisher TEXT,
  volumes INTEGER,                    -- 13
  source_id INTEGER REFERENCES data_sources(id), -- مصدر النص الرقمي
  license_status TEXT NOT NULL DEFAULT 'pending', -- approved | pending | rejected | noncommercial_only
  commercial_allowed INTEGER NOT NULL DEFAULT 0,  -- 0 حتى يثبت العكس
  status TEXT NOT NULL DEFAULT 'draft',          -- draft | published
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
```

### `commentary_passages` — فقرات الشرح (وحدة التخزين)

```sql
CREATE TABLE commentary_passages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id INTEGER NOT NULL REFERENCES commentary_books(id),
  volume INTEGER, page INTEGER,        -- الموضع المطبوع
  heading TEXT,                        -- عنوان الفقرة/الباب كما في الكتاب
  text_original TEXT NOT NULL,         -- نص الشرح الأصلي حرفياً
  text_simplified TEXT,                -- الشرح المبسط (منفصل تماماً)
  section TEXT NOT NULL,               -- vocab | summary | detailed | benefits | scholar_quotes | takhrij
  status TEXT NOT NULL DEFAULT 'draft',-- draft | pending_review | published | rejected
  created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX idx_passages_book ON commentary_passages(book_id);
```

### `commentary_links` — ربط الشرح بالحديث (علاقة مراجَعة، لا استنتاج)

```sql
CREATE TABLE commentary_links(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  passage_id INTEGER NOT NULL REFERENCES commentary_passages(id),
  hadith_id INTEGER NOT NULL REFERENCES hadiths(id),
  link_type TEXT NOT NULL DEFAULT 'manual', -- manual | suggested
  confidence REAL,                          -- 0..1 عند الاقتراح الآلي
  verified_by INTEGER REFERENCES admin_users(id),
  verified_at TEXT,
  status TEXT NOT NULL DEFAULT 'pending',    -- pending | verified | rejected
  UNIQUE(passage_id, hadith_id)
);
```

> ملاحظة علمية: الشرح كتاب متصل لا سجل لكل حديث؛ لذلك الربط علاقة مستقلة تُراجَع بشرياً، ولا يُنسَب شرح إلى حديث بغير دليل.

## 3. طبقة المصادر والتحقق (الاستقلال عن المصدر)

### `data_sources` — سجل كل مصدر وترخيصه

```sql
CREATE TABLE data_sources(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,          -- fawazahmed0 | sahih-bukhari-com-api | turath | shamela ...
  name TEXT NOT NULL,
  kind TEXT NOT NULL,                 -- file | api | manual
  homepage_url TEXT, license_name TEXT, license_url TEXT,
  commercial_allowed INTEGER NOT NULL DEFAULT 0,
  attribution_text TEXT NOT NULL,     -- نص النسبة الواجب إظهاره
  requires_key INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL
);
```

### `source_records` — من أين جاء كل سجل؟

```sql
CREATE TABLE source_records(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,          -- hadith | commentary_passage
  entity_id INTEGER NOT NULL,
  source_id INTEGER NOT NULL REFERENCES data_sources(id),
  source_ref TEXT,                    -- مرجع المصدر (مثال: ara-bukhari#1)
  source_url TEXT,                    -- الرابط الدائم canonical
  source_version TEXT,                -- إصدار البيانات (مثال: data_version أو hash الملف)
  retrieved_at TEXT NOT NULL,
  UNIQUE(entity_type, entity_id, source_id)
);
CREATE INDEX idx_source_records_entity ON source_records(entity_type, entity_id);
```

### `verification_checks` — تحقق عابر لا يُخزَّن كمحتوى

```sql
CREATE TABLE verification_checks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hadith_id INTEGER NOT NULL REFERENCES hadiths(id),
  checked_via TEXT NOT NULL,          -- sahih-bukhari-com-api
  data_version TEXT,                  -- إصدار بيانات الـ API وقت التحقق
  result TEXT NOT NULL,               -- match | mismatch | not_served | error
  detail TEXT,
  checked_at TEXT NOT NULL
);
```

### `coverage` — التغطية المعلنة لكل مجموعة

```sql
CREATE TABLE coverage(
  collection_id INTEGER PRIMARY KEY REFERENCES collections(id),
  total_on_source INTEGER, served INTEGER, not_served INTEGER,
  not_served_reasons TEXT,            -- JSON: {no_arabic: 15, licence: 0, ...}
  source_version TEXT, updated_at TEXT NOT NULL
);
```

### `excluded_records` — السجلات المستبعدة (بلا نص بديل)

```sql
CREATE TABLE excluded_records(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id INTEGER NOT NULL REFERENCES collections(id),
  hadith_number TEXT NOT NULL,
  reason TEXT NOT NULL,               -- licence_excluded | no_arabic | provenance_unverified | empty_text
  reason_detail TEXT,
  canonical_url TEXT,                 -- رابط القراءة الأصلية
  recorded_at TEXT NOT NULL,
  UNIQUE(collection_id, hadith_number)
);
```

### `import_runs` + `diff_audit` — الاستيراد والتحديث

```sql
CREATE TABLE import_runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL REFERENCES data_sources(id),
  collection_id INTEGER REFERENCES collections(id),
  source_version TEXT, file_hash TEXT,
  total_records INTEGER, imported INTEGER, skipped INTEGER,
  added INTEGER, changed INTEGER, unchanged INTEGER,
  errors TEXT,                        -- JSON للأخطاء
  status TEXT NOT NULL DEFAULT 'completed', -- running | completed | failed
  started_at TEXT NOT NULL, finished_at TEXT
);
CREATE TABLE diff_audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  import_run_id INTEGER REFERENCES import_runs(id),
  hadith_id INTEGER REFERENCES hadiths(id),
  hadith_number TEXT NOT NULL,
  diff_type TEXT NOT NULL,            -- added | text_changed | metadata_changed | removed_from_source | empty_text
  old_hash TEXT, new_hash TEXT, old_text TEXT, new_text TEXT,
  action TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  reviewed_by INTEGER REFERENCES admin_users(id),
  created_at TEXT NOT NULL
);
```

## 4. الحوكمة والإدارة

```sql
CREATE TABLE admin_users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,        -- SHA-256 + ملح، لا كلمة مرور نصية أبداً
  salt TEXT NOT NULL,
  role TEXT NOT NULL,                 -- admin | reviewer | editor
  created_at TEXT NOT NULL, last_login TEXT
);
CREATE TABLE content_reviews(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL,
  reviewer_id INTEGER REFERENCES admin_users(id),
  decision TEXT NOT NULL,             -- approved | rejected
  note TEXT, decided_at TEXT NOT NULL
);
CREATE TABLE audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER REFERENCES admin_users(id),
  action TEXT NOT NULL,               -- insert | update | delete | approve | reject | import | backup | login
  table_name TEXT, record_id INTEGER,
  old_value TEXT, new_value TEXT,     -- JSON
  created_at TEXT NOT NULL
);
CREATE TABLE backups(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  file_path TEXT NOT NULL, size_bytes INTEGER,
  sha256 TEXT, created_at TEXT NOT NULL
);
CREATE TABLE bookmarks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hadith_id INTEGER NOT NULL REFERENCES hadiths(id),
  note TEXT, created_at TEXT NOT NULL,
  UNIQUE(hadith_id)
);
```

## 5. البحث النصي الكامل (FTS5)

```sql
CREATE VIRTUAL TABLE hadiths_fts USING fts5(
  text_ar, content='hadiths', content_rowid='id',
  tokenize='unicode61'
);
CREATE VIRTUAL TABLE passages_fts USING fts5(
  text_original, text_simplified, content='commentary_passages', content_rowid='id',
  tokenize='unicode61'
);
-- مزامنة عبر triggers (insert/update/delete) أو إعادة بناء بعد الاستيراد.
-- البحث العربي: تطبيع (إزالة التشكيل والتطويل وتوحيد الألف والياء والتاء المربوطة) قبل الفهرسة والاستعلام.
```

## 6. الذكاء الاسترجاعي (اختياري لاحقاً — لا يؤثر في المخطط الأساسي)

```sql
CREATE TABLE embeddings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL,
  model TEXT NOT NULL, dims INTEGER NOT NULL,
  vector BLOB NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(entity_type, entity_id, model)
);
```

## 7. قواعد الانتقال للوضع التجاري (تُطبق باستعلام واحد)

```sql
-- أي محتوى غير تجاري يُستبعد تلقائياً عند تفعيل الوضع التجاري:
-- الشروح: WHERE commercial_allowed = 1
-- الأحاديث: ترخيص مصدرها Unlicense (تجاري مسموح) — تُحفظ commercial_allowed على مستوى data_sources
-- لا يُبنى أي مسار تشغيلي في v1 على محتوى commercial_allowed = 0
```

## 8. الترقيات (Migrations)

- جدول `schema_meta(key, value)` يحفظ `schema_version`.
- كل ترقية: رقم إصدار + أوامر SQL + اختبار رجوع. لا حذف لجداول قائمة دون ترحيل بياناتها.
- إضافة مجموعة جديدة (مسلم...) = صف في `collections` + استيراد عبر محوّل، دون تغيير المخطط.
- إضافة فتح الباري = صف في `commentary_books` + فقرات + روابط، دون تغيير المخطط.
