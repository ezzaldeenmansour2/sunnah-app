# بناء APK عبر GitHub Actions — خطوات دقيقة

السبب: بناء APK لا يعمل في بيئة التطوير الحالية لأن Gradle Daemon لا يستطيع
التواصل عبر loopback (التفاصيل في `docs/APK-CLOSING-REPORT.md`). الحل: البناء
على GitHub Actions، حيث يعمل الـ Daemon بشكل طبيعي. لا حاجة لأي حساب مدفوع:
GitHub Actions مجاني للمستودعات العامة، وله حصة شهرية مجانية للخاصة.

## ما هو جاهز

- ملف سير العمل: `.github/workflows/android.yml` (مثبّت Flutter 3.50.1 وJDK 17،
  يشغّل `flutter analyze` ثم `flutter test` ثم `flutter build apk --debug`،
  ويرفع APK كأرتيفاكت باسم `sunnah-debug-apk` لمدة 30 يوماً).
- ملف `android/gradle.properties` أُعيد إلى إعدادات قالب Flutter القياسية
  (إعدادات no-daemon المؤقتة أُزيلت لأنها لا تصلح ولا تنفع خارج بيئة التطوير).

## الخطوات (10 دقائق تقريباً)

1. فك ضغط حزمة المصدر `sunnah-app-p0-source.zip` في مجلد على حاسوبك.
2. أنشئ مستودعاً جديداً على GitHub (مثلاً باسم `sunnah-app`)، عام أو خاص.
3. من داخل مجلد المصدر، نفّذ:
   ```bash
   git init
   git add .
   git commit -m "SUNNAH P0: app + Studio + core + CI build"
   git branch -M main
   git remote add origin https://github.com/<اسمك>/sunnah-app.git
   git push -u origin main
   ```
   (سيطلب GitHub اسم المستخدم وكلمة المرور/التوكن — أنشئ Personal Access Token
   من Settings → Developer settings → Personal access tokens إذا طلب.)
4. افتح المستودع على GitHub → تبويب **Actions** → ستجد تشغيلاً باسم
   «Android APK (SUNNAH)» يعمل تلقائياً بعد الدفع. انتظر حتى تظهر علامة ✅.
   (أو شغّله يدوياً من Actions → Android APK (SUNNAH) → Run workflow.)
5. بعد نجاح التشغيل، افتحه وانزل إلى **Artifacts** → نزّل `sunnah-debug-apk`
   (ملف ZIP فيه `app-debug.apk`).
6. ثبّت APK على هاتف Android (فعّل «التثبيت من مصادر غير معروفة» عند الطلب).
7. انقل ملف الحزمة `arbaeen-nawawi-v1.sunnahpkg` إلى الهاتف (USB أو مشاركة ملفات)،
   ثم من داخل التطبيق: «استيراد حزمة» ← اختر الملف ← تحقق من ظهور
   «الأربعون النووية — 42 حديثاً» ← ابحث عن «الأعمال بالنيات» ← افتح الحديث 1.

## ملاحظات

- الـ APK الناتج **debug** (موقّع بمفاتيح التصحيح) — قابل للتثبيت والاختبار،
  وهو المطلوب لإغلاق P0. توقيع الإصدار (release) خطوة لاحقة، وليست من P0.
- كل دفع جديد إلى `main` يعيد البناء تلقائياً؛ كل تشغيل يرفع APK جديداً.
- إذا فشل تشغيل Actions، افتح سجل الخطوة الحمراء وانسخ رسالة الخطأ — السبب
  يكون عادة اختلاف إصدار أو خطأ شبكي مؤقت، لا مشكلة في كود التطبيق
  (الاختبارات والتحليل يعملان محلياً: `flutter test` ‏5/5، و`flutter analyze` نظيف).
- ملف `android/local.properties` غير مشمول في حزمة المصدر عمداً: فيه مسارات
  خاصة ببيئة التطوير هنا، ويولَّد تلقائياً في CI وعلى حاسوبك.
