#!/usr/bin/env python3
"""Regenerate the Android launcher icons as plain solid-colour PNGs.

Why this exists: the repository stores text sources only (the GitHub
connector's snapshot push accepts UTF-8 files, no binaries), so the
mipmap ic_launcher.png files are not committed. The APK build (aapt)
needs them, so CI regenerates simple placeholders here. The real
launcher icons are restored with a normal git push later; nothing about
the app's behaviour depends on these images.

Sizes are the standard Android launcher sizes. Colour is the app's teal.
Pure standard library: writes a valid PNG (IHDR + IDAT + IEND) with zlib.
Run from the repository root:  python3 tool/restore_android_icons.py
"""

import os
import struct
import sys
import zlib

# (mipmap folder, icon size in px)
ICONS = [
    ("mipmap-mdpi", 48),
    ("mipmap-hdpi", 72),
    ("mipmap-xhdpi", 96),
    ("mipmap-xxhdpi", 144),
    ("mipmap-xxxhdpi", 192),
]

# App teal (#008080-ish) as RGB.
RGB = (0, 128, 128)


def _chunk(kind: bytes, data: bytes) -> bytes:
    return (
        struct.pack(">I", len(data))
        + kind
        + data
        + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    )


def solid_png(size: int, rgb: tuple) -> bytes:
    r, g, b = rgb
    # One scanline: filter byte 0 + RGB pixels, repeated for every row.
    row = b"\x00" + bytes((r, g, b)) * size
    raw = row * size
    ihdr = struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + _chunk(b"IHDR", ihdr)
        + _chunk(b"IDAT", zlib.compress(raw))
        + _chunk(b"IEND", b"")
    )


def main() -> int:
    root = os.path.join("android", "app", "src", "main", "res")
    if not os.path.isdir(root):
        print(f"res dir not found: {root} (run from the repo root)", file=sys.stderr)
        return 1
    for folder, size in ICONS:
        path = os.path.join(root, folder, "ic_launcher.png")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            f.write(solid_png(size, RGB))
        print(f"wrote {path} ({size}x{size})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
