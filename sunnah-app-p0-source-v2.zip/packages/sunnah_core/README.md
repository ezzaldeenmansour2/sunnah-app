# sunnah_core — الحزمة المشتركة (Dart خالص، بلا Flutter)

حزمة Dart خالصة تحمل المنطق المشترك بين تطبيق Android وSUNNAH Studio،
بحيث يستحيل انحراف المنطق بينهما. لا تعتمد على flutter ولا على sqflite؛
قاعدة البيانات هنا عبر حزمة `sqlite3` (Dart FFI) والملف الناتج هو SQLite
قياسي يفتحه تطبيق Android عبر sqflite دون أي تحويل.

## البنية

```
lib/
  sunnah_core.dart        # التصديرات العامة
  src/
    normalize.dart        # التطبيع العربي (بحث) + إزالة التشكيل
    schema.dart           # مخطط P0 (DDL + FTS5 + محفزات المزامنة)
    chunking.dart         # تحليل نص الأربعين النووية إلى كتل أحاديث
    content_db.dart       # بناء content.sqlite + البحث النصي (FTS5)
    package.dart          # بناء/توقيع/التحقق من حزم .sunnahpkg
    keys.dart             # توليد مفاتيح Ed25519 وحفظ الخاص مشفراً
test/
  normalize_test.dart
  chunking_test.dart
  content_db_test.dart    # يبني قاعدة من النص الحقيقي ويبحث فيها
  package_test.dart       # توقيع سليم + رفض الحزمة المعدلة/غير الصالحة
```

## قاعدة P0

- الإدخال: ملف TXT (الأربعون النووية) — PDF/EPUB في Studio (P0: TXT فقط في خط الأنابيب؛ PDF يُختبَر ميكانيكياً عبر pdfrx في مشروع التوافق).
- لا OCR، لا بحث دلالي، لا ربط آلي، لا مساعد متقدم في هذه الحزمة.
- كل نص محفوظ كما هو (`text`) + نسخة مطبعة للبحث (`text_normalized`) + بصمة SHA-256.
