/// Arabic text normalization for search (FTS5) and matching.
///
/// The raw text is NEVER modified by this file. Normalization applies only
/// to the derived `text_normalized` column used for indexing and querying.
///
/// Rules (documented in 02-DATABASE-SCHEMA.md / 07-ARCHITECTURE.md):
/// - strip tashkeel (U+064B..U+065F), superscript alef (U+0670), tatweel (U+0640)
/// - unify alef variants (أ إ آ ٱ) -> ا
/// - alef maksura (ى) -> ي
/// - teh marbuta (ة) -> ه
/// - hamza carriers (ؤ -> و, ئ -> ي)
/// - Arabic-Indic digits (٠-٩) -> Western digits (0-9)
/// - the ligature ﷺ (U+FDFA) -> its expanded wording (search only)
/// - collapse whitespace
library;

const _arabicIndicDigits = '٠١٢٣٤٥٦٧٨٩';

String normalizeArabic(String input) {
  var s = input;
  // Tashkeel + tatweel + superscript alef.
  s = s.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '');
  // Alef variants.
  s = s.replaceAll(RegExp(r'[أإآٱ]'), 'ا');
  // Alef maksura -> yeh.
  s = s.replaceAll('ى', 'ي');
  // Teh marbuta -> heh.
  s = s.replaceAll('ة', 'ه');
  // Hamza carriers.
  s = s.replaceAll('ؤ', 'و').replaceAll('ئ', 'ي');
  // Ligature for the salutation.
  s = s.replaceAll('\uFDFA', 'صلى الله عليه وسلم');
  // Arabic-Indic digits -> Western digits.
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(_arabicIndicDigits[i], '$i');
  }
  // Collapse whitespace.
  s = s.replaceAll(RegExp(r'\s+'), ' ').trim();
  return s;
}
