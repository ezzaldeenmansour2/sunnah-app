/// Ed25519 key management for content-package signing.
///
/// The private key is held ONLY by the publisher (SUNNAH Studio).
/// It is stored as a file encrypted with AES-256-GCM; the encryption key is
/// derived from a passphrase with Argon2id. The public key is published
/// (embedded in the Android app as a trusted key) and is NOT secret.
///
/// Key format on disk (JSON):
///   {"key_id": "...", "salt": "<base64 16B>", "nonce": "<base64 12B>",
///    "ciphertext": "<base64: 32B private key seed, AES-GCM encrypted>"}
library;

import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography_plus/cryptography_plus.dart';

class PublisherKey {
  PublisherKey({
    required this.keyId,
    required this.keyPair,
  });

  final String keyId;
  final SimpleKeyPair keyPair;

  Future<SimplePublicKey> get publicKey async =>
      await keyPair.extractPublicKey();

  Future<String> get publicKeyBase64 async {
    final pub = await publicKey;
    return base64.encode(pub.bytes);
  }
}

/// Generate a fresh Ed25519 key pair.
Future<PublisherKey> generatePublisherKey(String keyId) async {
  final algorithm = Ed25519();
  final pair = await algorithm.newKeyPair();
  return PublisherKey(keyId: keyId, keyPair: pair);
}

/// Save [key] to [path], encrypted with [passphrase].
Future<void> saveEncryptedPrivateKey(
  PublisherKey key,
  String passphrase,
  String path,
) async {
  final seed = await key.keyPair.extractPrivateKeyBytes();
  final salt = _randomBytes(16);
  final kdf = Argon2id(
    parallelism: 1,
    memory: 19 * 1024, // 19 MiB
    iterations: 2,
    hashLength: 32,
  );
  final secretKey = await kdf.deriveKey(
    secretKey: SecretKey(utf8.encode(passphrase)),
    nonce: salt,
  );
  final aes = AesGcm.with256bits();
  final nonce = _randomBytes(12);
  final secretBox = await aes.encrypt(
    seed,
    secretKey: secretKey,
    nonce: nonce,
  );
  final doc = {
    'key_id': key.keyId,
    'kdf': 'argon2id',
    'salt': base64.encode(salt),
    'nonce': base64.encode(nonce),
    'ciphertext': base64.encode(secretBox.cipherText + secretBox.mac.bytes),
  };
  await File(path).writeAsString(
    const JsonEncoder.withIndent('  ').convert(doc),
  );
}

/// Load an encrypted private key from [path] using [passphrase].
Future<PublisherKey> loadEncryptedPrivateKey(
  String passphrase,
  String path,
) async {
  final doc =
      jsonDecode(await File(path).readAsString()) as Map<String, dynamic>;
  final salt = base64.decode(doc['salt'] as String);
  final nonce = base64.decode(doc['nonce'] as String);
  final blob = base64.decode(doc['ciphertext'] as String);
  final cipherText = blob.sublist(0, blob.length - 16);
  final mac = Mac(blob.sublist(blob.length - 16));
  final kdf = Argon2id(
    parallelism: 1,
    memory: 19 * 1024,
    iterations: 2,
    hashLength: 32,
  );
  final secretKey = await kdf.deriveKey(
    secretKey: SecretKey(utf8.encode(passphrase)),
    nonce: salt,
  );
  final aes = AesGcm.with256bits();
  final seed = await aes.decrypt(
    SecretBox(cipherText, nonce: nonce, mac: mac),
    secretKey: secretKey,
  );
  final algorithm = Ed25519();
  final pair = await algorithm.newKeyPairFromSeed(seed);
  return PublisherKey(keyId: doc['key_id'] as String, keyPair: pair);
}

Uint8List _randomBytes(int length) {
  final rnd = Random.secure();
  return Uint8List.fromList(
    List<int>.generate(length, (_) => rnd.nextInt(256)),
  );
}
