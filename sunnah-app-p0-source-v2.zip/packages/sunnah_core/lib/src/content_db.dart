/// Building and querying the packaged content database (content.sqlite).
///
/// Uses `package:sqlite3` (pure Dart FFI) so the pipeline runs in a plain
/// `dart run` / `dart test` without Flutter. The produced file is standard
/// SQLite; the Android app opens the same file with sqflite.
library;

import 'dart:io';

import 'package:sqlite3/sqlite3.dart';

import 'chunking.dart';
import 'normalize.dart';
import 'schema.dart';

class ContentDb {
  ContentDb._(this._db);

  final Database _db;

  /// Create a fresh content database at [path] from parsed [chunks].
  ///
  /// [book] / [edition] describe the packaged book; [sourceSha256] is the
  /// SHA-256 of the original source file; [sourceFormat] is e.g. 'txt'.
  static ContentDb build({
    required String path,
    required String bookTitle,
    required String? bookAuthor,
    required String editionLabel,
    required String? publisher,
    required int? printYear,
    required String source,
    required String licenseStatus,
    required bool commercialAllowed,
    required String sourceSha256,
    required String sourceFormat,
    required List<Chunk> chunks,
  }) {
    final file = File(path);
    if (file.existsSync()) file.deleteSync();
    final db = sqlite3.open(path);
    try {
      db.execute('PRAGMA foreign_keys = ON');
      db.execute(kSchemaDdl);
      db.execute(
        'INSERT INTO schema_meta(key, value) VALUES (?, ?)',
        ['schema_version', '$kSchemaVersion'],
      );
      db.execute(
        'INSERT INTO books(title, author, kind) VALUES (?, ?, ?)',
        [bookTitle, bookAuthor, 'hadith_collection'],
      );
      final bookId = db.lastInsertRowId;
      db.execute(
        'INSERT INTO editions(book_id, edition_label, publisher, print_year, '
        'source, license_status, commercial_allowed) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
          bookId,
          editionLabel,
          publisher,
          printYear,
          source,
          licenseStatus,
          commercialAllowed ? 1 : 0,
        ],
      );
      final editionId = db.lastInsertRowId;
      db.execute(
        'INSERT INTO files(edition_id, format, sha256, file_size, page_count) '
        'VALUES (?, ?, ?, ?, ?)',
        [editionId, sourceFormat, sourceSha256, null, null],
      );
      final stmt = db.prepare(
        'INSERT INTO chunks(edition_id, kind, ref_number, title, narrator, '
        'text, text_normalized, text_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      );
      try {
        for (final c in chunks) {
          stmt.execute([
            editionId,
            c.kind,
            c.refNumber,
            c.title,
            c.narrator,
            c.text,
            c.normalized,
            c.textHash,
          ]);
        }
      } finally {
        stmt.dispose();
      }
      // Rebuild the FTS index explicitly (triggers already maintain it;
      // rebuild guarantees consistency after bulk insert).
      db.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')");
      db.execute('VACUUM');
      return ContentDb._(db);
    } catch (_) {
      db.dispose();
      rethrow;
    }
  }

  /// Open an existing content database read-only (as the app does).
  static ContentDb openReadOnly(String path) {
    final db = sqlite3.open(path, mode: OpenMode.readOnly);
    return ContentDb._(db);
  }

  void close() => _db.dispose();

  int get schemaVersion {
    final rows = _db.select(
      "SELECT value FROM schema_meta WHERE key = 'schema_version'",
    );
    if (rows.isEmpty) return 0;
    return int.tryParse(rows.first['value'] as String? ?? '') ?? 0;
  }

  int get chunkCount {
    final rows = _db.select('SELECT COUNT(*) AS n FROM chunks');
    return rows.first['n'] as int;
  }

  int get hadithCount {
    final rows =
        _db.select("SELECT COUNT(*) AS n FROM chunks WHERE kind = 'hadith'");
    return rows.first['n'] as int;
  }

  /// FTS5 phrase search. [query] is the user's raw query; it is normalized
  /// here and searched as an exact phrase on the normalized text.
  List<Map<String, Object?>> searchPhrase(String query, {int limit = 10}) {
    final normalized = normalizeArabic(query);
    if (normalized.isEmpty) return const [];
    final rows = _db.select(kFtsPhraseSearchSql, ['"$normalized"', limit]);
    return rows.map((r) => Map<String, Object?>.from(r)).toList();
  }

  /// Keyword search (all terms, any order) — fallback when the phrase
  /// search finds nothing.
  List<Map<String, Object?>> searchKeywords(String query, {int limit = 10}) {
    final normalized = normalizeArabic(query);
    final terms =
        normalized.split(' ').where((t) => t.isNotEmpty).toList();
    if (terms.isEmpty) return const [];
    final match = terms.map((t) => '"$t"').join(' AND ');
    final rows = _db.select(kFtsPhraseSearchSql, [match, limit]);
    return rows.map((r) => Map<String, Object?>.from(r)).toList();
  }

  Map<String, Object?>? chunkByRef(int editionId, String refNumber) {
    final rows = _db.select(kChunkByRefSql, [editionId, refNumber]);
    if (rows.isEmpty) return null;
    return Map<String, Object?>.from(rows.first);
  }
}
