/// P0 database schema (subset of 02-DATABASE-SCHEMA.md).
///
/// The same DDL is used by the pipeline (via `sqlite3`) and by the Android
/// app (via sqflite opening the packaged file). FTS5 is an external-content
/// table kept in sync with `chunks` by triggers, so the packaged file can be
/// opened read-only by the app and still be searchable.
library;

/// Current schema version written into `schema_meta`.
const int kSchemaVersion = 1;

const String kSchemaDdl = '''
CREATE TABLE IF NOT EXISTS schema_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  author TEXT,
  kind TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS editions (
  id INTEGER PRIMARY KEY,
  book_id INTEGER NOT NULL REFERENCES books(id),
  edition_label TEXT NOT NULL,
  publisher TEXT,
  print_year INTEGER,
  source TEXT,
  license_status TEXT NOT NULL,
  commercial_allowed INTEGER NOT NULL DEFAULT 0,
  UNIQUE(book_id, edition_label)
);

CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY,
  edition_id INTEGER NOT NULL REFERENCES editions(id),
  format TEXT NOT NULL,
  sha256 TEXT NOT NULL UNIQUE,
  file_size INTEGER,
  page_count INTEGER
);

CREATE TABLE IF NOT EXISTS chunks (
  id INTEGER PRIMARY KEY,
  edition_id INTEGER NOT NULL REFERENCES editions(id),
  kind TEXT NOT NULL,
  ref_number TEXT,
  title TEXT,
  narrator TEXT,
  text TEXT NOT NULL,
  text_normalized TEXT NOT NULL,
  text_hash TEXT NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
  text_normalized,
  content='chunks',
  content_rowid='id',
  tokenize='unicode61'
);

CREATE TRIGGER IF NOT EXISTS chunks_fts_ai AFTER INSERT ON chunks BEGIN
  INSERT INTO chunks_fts(rowid, text_normalized)
  VALUES (new.id, new.text_normalized);
END;

CREATE TRIGGER IF NOT EXISTS chunks_fts_ad AFTER DELETE ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, text_normalized)
  VALUES ('delete', old.id, old.text_normalized);
END;

CREATE TRIGGER IF NOT EXISTS chunks_fts_au AFTER UPDATE ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, text_normalized)
  VALUES ('delete', old.id, old.text_normalized);
  INSERT INTO chunks_fts(rowid, text_normalized)
  VALUES (new.id, new.text_normalized);
END;
''';

/// FTS5 phrase search over the normalized text.
///
/// Returns chunk rows ordered by FTS5 rank (best match first).
/// The caller must normalize [query] with [normalizeArabic] first and pass
/// it as a quoted phrase: `"<normalized query>"`.
const String kFtsPhraseSearchSql = '''
SELECT c.id, c.kind, c.ref_number, c.title, c.narrator, c.text,
       c.edition_id, bm25(chunks_fts) AS rank
FROM chunks_fts
JOIN chunks c ON c.id = chunks_fts.rowid
WHERE chunks_fts MATCH ?
ORDER BY rank
LIMIT ?;
''';

/// Exact lookup of one chunk by edition + reference number.
const String kChunkByRefSql = '''
SELECT id, kind, ref_number, title, narrator, text
FROM chunks
WHERE edition_id = ? AND ref_number = ?
LIMIT 1;
''';
