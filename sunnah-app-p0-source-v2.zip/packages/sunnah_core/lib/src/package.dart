/// Content-package (.sunnahpkg) build, signing and verification.
///
/// A package is a ZIP containing:
///   manifest.json   — signed metadata (see [buildManifest])
///   content.sqlite  — the content database
///   originals/<file> — the original source file (optional in v1)
///
/// Signing: Ed25519 over the canonical manifest bytes (manifest JSON with
/// keys sorted, no whitespace, WITHOUT the `signature` field itself).
/// Verification runs 6 checks (see [verifyPackage]); ANY failure rejects
/// the whole package — imports are atomic (all or nothing).
library;

import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart' as crypto;
import 'package:cryptography_plus/cryptography_plus.dart';

import 'keys.dart';

const int kPackageFormatVersion = 1;

/// Canonical JSON: sorted keys, no whitespace. Used for signing.
String canonicalJson(Map<String, Object?> value) {
  final sorted = _sortDeep(value);
  return jsonEncode(sorted);
}

Object? _sortDeep(Object? value) {
  if (value is Map) {
    final keys = value.keys.map((k) => k.toString()).toList()..sort();
    return {
      for (final k in keys) k: _sortDeep(value[k]),
    };
  }
  if (value is List) return value.map(_sortDeep).toList();
  return value;
}

String sha256HexOfBytes(List<int> bytes) =>
    crypto.sha256.convert(bytes).toString();

String sha256HexOfFile(String path) =>
    sha256HexOfBytes(File(path).readAsBytesSync());

class PackageFileEntry {
  PackageFileEntry({required this.path, required this.sha256, required this.size});

  final String path;
  final String sha256;
  final int size;

  Map<String, Object?> toJson() =>
      {'path': path, 'sha256': sha256, 'size': size};
}

class PackageManifest {
  PackageManifest({
    required this.packageId,
    required this.packageVersion,
    required this.schemaVersion,
    required this.keyId,
    required this.book,
    required this.contents,
    required this.files,
    this.supersedes,
  });

  final String packageId;
  final int packageVersion;
  final int schemaVersion;
  final String keyId;
  final Map<String, Object?> book;
  final Map<String, Object?> contents;
  final List<PackageFileEntry> files;
  final int? supersedes;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'package_format': kPackageFormatVersion,
      'package_id': packageId,
      'package_version': packageVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'created_by': 'SUNNAH Studio 0.1.0 (P0)',
      'schema_version': schemaVersion,
      'key_id': keyId,
      'book': book,
      'contents': contents,
      'files': files.map((f) => f.toJson()).toList(),
      'supersedes': supersedes,
    };
  }
}

/// Build a signed .sunnahpkg from [contentDbPath] (+ optional original file).
///
/// Returns the path of the written package file.
Future<String> buildPackage({
  required PackageManifest manifest,
  required String contentDbPath,
  String? originalFilePath,
  required PublisherKey signingKey,
  required String outputPath,
}) async {
  final archive = Archive();
  final contentDbBytes = File(contentDbPath).readAsBytesSync();
  final entries = <PackageFileEntry>[
    PackageFileEntry(
      path: 'content.sqlite',
      sha256: sha256HexOfBytes(contentDbBytes),
      size: contentDbBytes.length,
    ),
  ];
  final files = <String, List<int>>{'content.sqlite': contentDbBytes};
  if (originalFilePath != null) {
    final bytes = File(originalFilePath).readAsBytesSync();
    final name = 'originals/${originalFilePath.split('/').last}';
    entries.add(PackageFileEntry(
      path: name,
      sha256: sha256HexOfBytes(bytes),
      size: bytes.length,
    ));
    files[name] = bytes;
  }
  final manifestWithFiles = PackageManifest(
    packageId: manifest.packageId,
    packageVersion: manifest.packageVersion,
    schemaVersion: manifest.schemaVersion,
    keyId: manifest.keyId,
    book: manifest.book,
    contents: manifest.contents,
    files: entries,
    supersedes: manifest.supersedes,
  );
  // Sign the canonical manifest WITHOUT the signature field.
  // NOTE: toJson() is called ONCE — it stamps created_at, so calling it
  // twice would sign one timestamp and store another.
  final unsignedManifest = manifestWithFiles.toJson();
  final canonical = canonicalJson(unsignedManifest);
  final algorithm = Ed25519();
  final signature = await algorithm.sign(
    utf8.encode(canonical),
    keyPair: signingKey.keyPair,
  );
  final signedManifest = Map<String, Object?>.from(unsignedManifest)
    ..['signature'] = base64.encode(signature.bytes);
  final manifestBytes = utf8.encode(
    const JsonEncoder.withIndent('  ').convert(signedManifest),
  );
  archive.addFile(ArchiveFile('manifest.json', manifestBytes.length, manifestBytes));
  for (final entry in files.entries) {
    archive.addFile(ArchiveFile(entry.key, entry.value.length, entry.value));
  }
  final zipBytes = ZipEncoder().encode(archive);
  await File(outputPath).writeAsBytes(zipBytes);
  return outputPath;
}

class PackageVerification {
  PackageVerification({required this.ok, required this.errors, this.manifest});

  final bool ok;
  final List<String> errors;
  final Map<String, dynamic>? manifest;
}

class TrustedKey {
  TrustedKey({required this.keyId, required this.publicKeyBase64});

  final String keyId;
  final String publicKeyBase64;
}

/// Verify a .sunnahpkg against [trustedKeys] (6 checks, all mandatory).
///
/// 1. ZIP structure + manifest.json present and valid + supported format.
/// 2. SHA-256 of every file matches the manifest; no extra files.
/// 3. Ed25519 signature valid with a trusted public key (key_id known).
/// 4. schema_version compatible with [appSchemaVersion].
/// 5. license_status known (+ commercial consistency when
///    [commercialMode] is true).
/// 6. No conflict with an already-installed package version
///    ([installedVersion] of the same package_id, if any).
Future<PackageVerification> verifyPackage({
  required String packagePath,
  required List<TrustedKey> trustedKeys,
  required int appSchemaVersion,
  bool commercialMode = false,
  int? installedVersion,
}) async {
  final errors = <String>[];
  late Archive archive;
  try {
    final bytes = await File(packagePath).readAsBytes();
    archive = ZipDecoder().decodeBytes(bytes);
  } catch (e) {
    return PackageVerification(
      ok: false,
      errors: ['الحزمة ليست ملف ZIP صالحاً: $e'],
    );
  }
  final manifestFile = archive.files.where((f) => f.name == 'manifest.json');
  if (manifestFile.isEmpty) {
    return PackageVerification(
      ok: false,
      errors: ['manifest.json غير موجود في الحزمة'],
    );
  }
  late Map<String, dynamic> manifest;
  try {
    manifest = jsonDecode(
      utf8.decode(manifestFile.first.content as List<int>),
    ) as Map<String, dynamic>;
  } catch (e) {
    return PackageVerification(
      ok: false,
      errors: ['manifest.json غير صالح: $e'],
    );
  }
  // 1. Format.
  final format = manifest['package_format'];
  if (format != kPackageFormatVersion) {
    errors.add('إصدار صيغة الحزمة غير مدعوم: $format');
  }
  // 2. File hashes + no extra files.
  final declared = <String, Map<String, dynamic>>{};
  final filesList = manifest['files'] as List<dynamic>? ?? [];
  for (final f in filesList) {
    final m = f as Map<String, dynamic>;
    declared[m['path'] as String] = m;
  }
  for (final f in archive.files) {
    if (f.name == 'manifest.json' || f.isFile == false) continue;
    final d = declared[f.name];
    if (d == null) {
      errors.add('ملف زائد غير مذكور في البيان: ${f.name}');
      continue;
    }
    final actual = sha256HexOfBytes(f.content as List<int>);
    if (actual != d['sha256']) {
      errors.add('بصمة الملف لا تطابق البيان: ${f.name}');
    }
    if (f.size != d['size']) {
      errors.add('حجم الملف لا يطابق البيان: ${f.name}');
    }
  }
  for (final name in declared.keys) {
    if (!archive.files.any((f) => f.name == name)) {
      errors.add('ملف مذكور في البيان مفقود من الحزمة: $name');
    }
  }
  // 3. Signature.
  final signatureB64 = manifest['signature'] as String?;
  final keyId = manifest['key_id'] as String?;
  if (signatureB64 == null || signatureB64.isEmpty) {
    errors.add('الحزمة بلا توقيع');
  } else if (keyId == null) {
    errors.add('البيان بلا key_id');
  } else {
    final trusted = trustedKeys.where((k) => k.keyId == keyId).toList();
    if (trusted.isEmpty) {
      errors.add('مفتاح التوقيع غير موثوق: $keyId');
    } else {
      final unsigned = Map<String, dynamic>.from(manifest)..remove('signature');
      final canonical = canonicalJson(unsigned);
      try {
        final algorithm = Ed25519();
        final pub = SimplePublicKey(
          base64.decode(trusted.first.publicKeyBase64),
          type: KeyPairType.ed25519,
        );
        final sig = Signature(
          base64.decode(signatureB64),
          publicKey: pub,
        );
        final valid = await algorithm.verify(
          utf8.encode(canonical),
          signature: sig,
        );
        if (!valid) errors.add('التوقيع غير صالح — قد تكون الحزمة معدَّلة');
      } catch (e) {
        errors.add('تعذر التحقق من التوقيع: $e');
      }
    }
  }
  // 4. Schema version.
  final schemaVersion = manifest['schema_version'];
  if (schemaVersion is! int) {
    errors.add('schema_version غير صالح في البيان');
  } else if (schemaVersion > appSchemaVersion) {
    errors.add(
      'الحزمة تحتاج مخططاً أحدث (v$schemaVersion) — حدّث التطبيق (v$appSchemaVersion)',
    );
  }
  // 5. Licence.
  final book = manifest['book'] as Map<String, dynamic>?;
  final license = book?['license_status'] as String?;
  const knownLicenses = {'public_domain', 'unlicense', 'cc_by', 'cc_by_sa', 'permission_granted'};
  if (license == null || !knownLicenses.contains(license)) {
    errors.add('حالة ترخيص غير معروفة في البيان: $license');
  } else if (commercialMode && book?['commercial_allowed'] != true) {
    errors.add('الحزمة غير مسموح بها تجارياً والتطبيق في الوضع التجاري');
  }
  // 6. Version conflict.
  final pkgVersion = manifest['package_version'];
  if (pkgVersion is int && installedVersion != null && pkgVersion <= installedVersion) {
    errors.add(
      'إصدار الحزمة ($pkgVersion) ليس أحدث من المثبت ($installedVersion)',
    );
  }
  return PackageVerification(
    ok: errors.isEmpty,
    errors: errors,
    manifest: errors.isEmpty ? manifest : manifest,
  );
}
