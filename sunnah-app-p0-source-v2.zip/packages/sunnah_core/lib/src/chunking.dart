/// Parsing of the Forty Nawawi plain-text source into hadith blocks.
///
/// Source format (see sunnah-app/test-data/PROVENANCE.md):
///   الحديث 1: <title>
///   <narrator line, starts with "عن ">
///   <matn lines...>
///   رواه <takhrij>
/// Blocks are separated by a blank line. The file header (book title +
/// author) precedes the first marker and becomes the intro chunk.
library;

import 'package:crypto/crypto.dart' as crypto;
import 'dart:convert';

import 'normalize.dart';

class HadithBlock {
  HadithBlock({
    required this.number,
    required this.title,
    required this.narrator,
    required this.text,
    required this.takhrij,
  });

  final int number;
  final String title;
  final String narrator;
  final String text;
  final String takhrij;

  /// The chunk text as stored: narrator + matn + takhrij, verbatim.
  String get chunkText => '$narrator\n$text\n$takhrij';

  String get textHash =>
      crypto.sha256.convert(utf8.encode(chunkText)).toString();
}

class ParsedBook {
  ParsedBook({required this.intro, required this.hadiths});

  final String intro;
  final List<HadithBlock> hadiths;
}

final _marker = RegExp(r'^الحديث (\d+):\s*(.*)$');

ParsedBook parseNawawiText(String content) {
  final lines = content.split('\n');
  final introLines = <String>[];
  final hadiths = <HadithBlock>[];
  var i = 0;

  // Header: everything before the first marker.
  while (i < lines.length && !_marker.hasMatch(lines[i].trim())) {
    final t = lines[i].trim();
    if (t.isNotEmpty) introLines.add(t);
    i++;
  }

  while (i < lines.length) {
    final m = _marker.firstMatch(lines[i].trim());
    if (m == null) {
      // Blank lines between blocks; anything else is a format error.
      if (lines[i].trim().isNotEmpty) {
        throw FormatException(
          'Unexpected line outside a hadith block (line ${i + 1}): ${lines[i]}',
        );
      }
      i++;
      continue;
    }
    final number = int.parse(m.group(1)!);
    final title = m.group(2)!.trim();
    i++;
    final blockLines = <String>[];
    while (i < lines.length && !_marker.hasMatch(lines[i].trim())) {
      blockLines.add(lines[i]);
      i++;
    }
    // Drop trailing blank lines of the block.
    while (blockLines.isNotEmpty && blockLines.last.trim().isEmpty) {
      blockLines.removeLast();
    }
    if (blockLines.isEmpty) {
      throw FormatException('Hadith $number has no body lines.');
    }
    final narrator = blockLines.first.trim();
    if (!narrator.startsWith('عن ')) {
      throw FormatException(
        'Hadith $number: expected narrator line starting with "عن ", got: $narrator',
      );
    }
    final rest = blockLines.sublist(1).map((l) => l.trim()).toList();
    if (rest.isEmpty) {
      throw FormatException('Hadith $number has no matn lines.');
    }
    final takhrij = rest.last;
    // Takhrij formulations vary: "رواه البخاري ومسلم", "حديث حسن، رواه
    // الترمذي...", "الأول رواه مسلم، والثاني رواه أحمد...", "حديث حسن،
    // رويناه في كتاب الحجة...". Accept any last line that cites a
    // narration verb (رواه / رويناه); anything else is a format error.
    if (!takhrij.contains('رواه') && !takhrij.contains('رويناه')) {
      throw FormatException(
        'Hadith $number: expected last line to cite a narration '
        '(رواه/رويناه), got: $takhrij',
      );
    }
    final matn = rest.sublist(0, rest.length - 1).join('\n').trim();
    if (matn.isEmpty) {
      throw FormatException('Hadith $number has an empty matn.');
    }
    hadiths.add(HadithBlock(
      number: number,
      title: title,
      narrator: narrator,
      text: matn,
      takhrij: takhrij,
    ));
  }

  if (hadiths.isEmpty) {
    throw const FormatException('No hadith blocks found in source text.');
  }
  final numbers = hadiths.map((h) => h.number).toList();
  for (var n = 1; n <= numbers.length; n++) {
    if (numbers[n - 1] != n) {
      throw FormatException(
        'Hadith numbers are not a continuous 1..${numbers.length} sequence '
        '(position ${n - 1} has ${numbers[n - 1]}).',
      );
    }
  }
  return ParsedBook(intro: introLines.join('\n'), hadiths: hadiths);
}

/// A chunk ready for insertion into [chunks].
class Chunk {
  Chunk({
    required this.kind,
    this.refNumber,
    this.title,
    this.narrator,
    required this.text,
  });

  final String kind; // 'intro' | 'hadith'
  final String? refNumber;
  final String? title;
  final String? narrator;
  final String text;

  String get normalized => normalizeArabic(text);

  String get textHash =>
      crypto.sha256.convert(utf8.encode(text)).toString();
}

/// One chunk per hadith (a hadith matn is NEVER split across chunks),
/// plus one intro chunk for the book header.
List<Chunk> chunkParsedBook(ParsedBook book) {
  final chunks = <Chunk>[
    Chunk(kind: 'intro', text: book.intro),
  ];
  for (final h in book.hadiths) {
    chunks.add(Chunk(
      kind: 'hadith',
      refNumber: '${h.number}',
      title: h.title,
      narrator: h.narrator,
      text: h.chunkText,
    ));
  }
  return chunks;
}
